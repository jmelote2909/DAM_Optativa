from tokenize import Double
import csv

ruta = "Simulacro examen T1/reservas_viajes.csv"

columnaDestino = []
columnaProducto = []
columnaPrecio = []
columnaUnidades = []
datos = {
    "Destino": {},
    "Producto": {},
    "Precio": {},
    "Unidades_reservadas":{}
}

with open(ruta, "r") as archivo:
    lector = csv.reader(archivo)

    next(lector)

    # LECTURA DE DATOS Y GUARDADO EN DICCIONARIO
    for fila in lector:
        columnaDestino.append((fila[0]))
        datos["Destino"] = columnaDestino
        columnaProducto.append((fila[1]))
        datos["Producto"] = columnaProducto
        columnaPrecio.append((fila[2]))
        datos["Precio"] = columnaPrecio
        columnaUnidades.append((fila[3]))
        datos["Unidades_reservadas"] = columnaUnidades

    # CALCULO DE Número total de registros procesados
    cont_Registros = 0
    for destino in datos["Destino"]:
        cont_Registros = cont_Registros + 1 

    # CALCULO DE Precio medio de todos los paquetes/productos ofertados.
    cont_Precio = 0
    for precio in datos["Precio"]:
        cont_Precio = cont_Precio + float(precio)

    # CALCULO DE El destino o producto más reservado, indicando el número total de unidades reservadas.
    cantMax_Reservas = 0
    destino_max_reservas = ""
    for unidades in datos["Unidades_reservadas"]:
        if (int(unidades) > int(cantMax_Reservas)):
            cantMax_Reservas = unidades
            destino_max_reservas = datos["Destino"]

    
    
print(datos)
print("Numero total de registros: ", cont_Registros)
print("Precio medio de los paquetes/productos ofertados: ", cont_Precio/cont_Registros)
print("El destino o producto más reservado, indicando el número total de unidades reservadas.", cantMax_Reservas)